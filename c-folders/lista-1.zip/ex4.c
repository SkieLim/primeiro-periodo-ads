#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>

int main (){

    int ano, mes, dia, total;

        printf("Quantos anos voce tem?\n");
            scanf("%i", &ano);


        printf("Qual mes voce nasceu em nuemros?\n");
            scanf("%i", &mes);


        printf("Que dia voce nasceu?\n");
            scanf("%i", &dia);


        ano = ano * 365;
        mes = mes * 30;
        total = ano + mes + dia;

        printf("sua idade total em dias ser equivalente a: %i\n", total);

    system("pause");
}
