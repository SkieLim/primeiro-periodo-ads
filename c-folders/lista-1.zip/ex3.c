#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>

int main() {

    float comb, kmp, lpkm;

        printf("quantos quilometros voc� percorreu?\n");
            scanf("%f", &kmp);

        printf("quantos litros de combustivel foram usados?\n");
            scanf("%f", &comb);

        lpkm = comb/kmp;

        printf("foram usados %f litros por km\n", lpkm);


    system("pause");
}
