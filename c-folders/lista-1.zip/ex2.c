#include <stdio.h>
#include <stdlib.h>

int main (){

    int num, ant, suc;

        printf("Digite um valor inteiro:\n");
            scanf("%i", &num);

            suc = num + 1;
            ant = num - 1;


        printf("O Sucessor de %i ser:%i\n", num, suc);
        printf("O Antecessor de %i ser:%i\n", num, ant);

    system("pause");
}
