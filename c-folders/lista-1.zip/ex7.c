#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>

int main(){

    float n1, n2, n3, med;

        printf("Digite a primeira nota?\n");
            scanf("%f", &n1);
        printf("Digite a segunda nota?\n");
            scanf("%f", &n2);
        printf("Digite a terceira nota?\n");
            scanf("%f", &n3);

        med = (n1 + n2 + n3)/3;

        printf("A Media das notas é: %.2f", med);

    system("pause");
}