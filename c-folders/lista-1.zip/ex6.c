#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>

int main(){

    float peso, altura, imc, potencia;

        printf("informe seu peso\n");
            scanf("%f", &peso);

        printf("informe sua altura\n");
            scanf("%f", &altura);

        potencia = pow(altura, 2);
        imc = peso/potencia;

        printf("seu indice de massa corporal ser: %f\n", imc);

    system("pause");
}
