#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>

int main(){

  float brl, dol;

    printf("quanto esta a cotação do dolar em real?\n");
     scanf("%f", &dol);

    printf("quantos reais voce quer converter?\n");
        scanf("%f", &brl);

    dol = dol * brl;

    printf("%.2f reais equivalem a %.2f dolares.\n", brl, dol);

  system("pause");
}
